import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { switchMap } from 'rxjs/operators';
import { Usuario } from 'src/app/_model/usuario';
import { UsuarioService } from 'src/app/_service/usuario.service';
import { UsuarioDialogoComponent as UsuarioDialogComponent } from './usuario-dialogo/usuario-dialogo.component';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {

  displayedColumns = ['idUsuario', 'Username', 'Nombre', 'Apellido', 'email'];
  dataSource?: MatTableDataSource<Usuario>;

  constructor(
    private usuarioService: UsuarioService,
    private dialog?: MatDialog,
    private snackBar?: MatSnackBar
  ) { }

  ngOnInit(): void {

    this.usuarioService.getUsuarioCambio().subscribe(data => {
      this.crearTabla(data);
    });


    this.usuarioService.listar().subscribe(data => {
      this.crearTabla(data);
    });
  }

  crearTabla(data: Usuario[]) {
    this.dataSource = new MatTableDataSource(data);

  }


  }


