import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { GenericService } from './generic.service';
import { Usuario } from '../_model/usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService  extends GenericService<Usuario>{

  private usuarioCambio = new Subject<Usuario[]>();
  private mensajeCambio = new Subject<string>();

  constructor(protected http: HttpClient) {
    super(
      http,
      `${environment.HOST}/usuarios`);
  }
  setMensajeCambio(mensaje: string) {
    this.mensajeCambio.next(mensaje);
  }

  getMensajeCambio() {
    return this.mensajeCambio.asObservable();
  }

  setUsuarioCambio(lista: Usuario[]) {
    this.usuarioCambio.next(lista);
  }

  getUsuarioCambio() {
    return this.usuarioCambio.asObservable();
  }


}
