export class Rol{
  idRol?: number;
  rolName?: string;
  owner?: string;
}
