import { Rol } from './rol';

export class Usuario{
    idUsuario?: number;
    username?: string;
    nombre?: string;
    apellido?: string;
    email?: string;
    roles?: Rol[];
}
